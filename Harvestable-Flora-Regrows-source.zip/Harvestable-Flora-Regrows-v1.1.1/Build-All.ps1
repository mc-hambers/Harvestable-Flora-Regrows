$ErrorActionPreference='Stop'
& "$PSScriptRoot/Build-Native.ps1"
& "$PSScriptRoot/tools/caprica/Caprica.exe" "$PSScriptRoot/Data/Scripts/Source" --game skyrim --ignorecwd --import "$PSScriptRoot/Data/Scripts/Source;$PSScriptRoot/tools/papyrus-headers" --flags "$PSScriptRoot/tools/TESV_Papyrus_Flags.flg" --output "$PSScriptRoot/Data/Scripts" *> "$PSScriptRoot/logs/papyrus-build.txt"
if($LASTEXITCODE -ne 0){throw 'Papyrus compilation failed; see logs/papyrus-build.txt'}
$python=if($env:HFR_PYTHON){$env:HFR_PYTHON}else{'python'}
& $python "$PSScriptRoot/tools/make_plugin.py"
if($LASTEXITCODE -ne 0){throw 'ESP generation failed'}
& $python "$PSScriptRoot/tools/package.py"
if($LASTEXITCODE -ne 0){throw 'Package verification failed'}
