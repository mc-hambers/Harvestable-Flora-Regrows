# Third-party code
- CommonLibSSE-NG v12.1.0, alandtse fork: https://github.com/alandtse/CommonLibSSE-NG/tree/v12.1.0. GPL-3.0; source and prebuilt library included under vendor/.
- fmt 12.2.0: https://github.com/fmtlib/fmt/tree/12.2.0. MIT license in vendor/fmt/.
- spdlog 1.16.0: https://github.com/gabime/spdlog/tree/v1.16.0. MIT license in vendor/spdlog/.
- SkyUI MCM API: https://github.com/schlangster/skyui/wiki/MCM-API-Reference. Required separately in game. Compile-only declarations are in tools/papyrus-headers/.
- Caprica 0.3.0: https://github.com/Orvid/Caprica/tree/v0.3.0. Used for compiling settings scripts, not shipped in the install ZIP.
- Microsoft compiler and SDK were extracted locally for building. They are not redistributed in either ZIP.

Harvestable Flora Regrows source is GPL-3.0-or-later. See LICENSE.

