Scriptname HFR_MCM extends SKI_ConfigBase
Int minOption = -1
Int maxOption = -1
Int inspectOption = -1
Int[] featureOptions
Int Function GetVersion()
    Return 4
EndFunction
Function SetPages()
    Pages = new String[3]
    Pages[0] = "General"
    Pages[1] = "Nirnroot"
    Pages[2] = "Compatibility"
EndFunction
Event OnConfigInit()
    ModName = "Harvestable Flora Regrows"
    SetPages()
EndEvent
Event OnConfigOpen()
    SetPages()
EndEvent
Event OnPageReset(String page)
    minOption = -1
    maxOption = -1
    inspectOption = -1
    featureOptions = new Int[7]
    Int i = 0
    While i < 7
        featureOptions[i] = -1
        i += 1
    EndWhile
    SetCursorFillMode(TOP_TO_BOTTOM)
    If page == "Nirnroot"
        AddHeaderOption("Nirnroot")
        featureOptions[1] = AddToggleOption("Regrow Nirnroot", HFR_Native.GetOption(1) != 0)
        Int flags = 0
        If HFR_Native.GetOption(1) == 0
            flags = OPTION_FLAG_DISABLED
        EndIf
        featureOptions[2] = AddToggleOption("Use custom time", HFR_Native.GetOption(2) != 0, flags)
        If HFR_Native.GetOption(2) == 0
            flags = OPTION_FLAG_DISABLED
        EndIf
        featureOptions[3] = AddSliderOption("Regrowth days", HFR_Native.GetOption(3), "{0}", flags)
        AddHeaderOption("Crimson Nirnroot")
        featureOptions[4] = AddToggleOption("Regrow Crimson Nirnroot", HFR_Native.GetOption(4) != 0)
        flags = 0
        If HFR_Native.GetOption(4) == 0
            flags = OPTION_FLAG_DISABLED
        EndIf
        featureOptions[5] = AddToggleOption("Use custom time", HFR_Native.GetOption(5) != 0, flags)
        If HFR_Native.GetOption(5) == 0
            flags = OPTION_FLAG_DISABLED
        EndIf
        featureOptions[6] = AddSliderOption("Regrowth days", HFR_Native.GetOption(6), "{0}", flags)
    ElseIf page == "Compatibility"
        AddHeaderOption("Immersive Interactions")
        Int compatFlags = 0
        If !HFR_Native.MilkAvailable()
            compatFlags = OPTION_FLAG_DISABLED
            AddTextOption("Status", "Not installed")
        Else
            AddTextOption("Status", "Detected")
        EndIf
        featureOptions[0] = AddToggleOption("Restore cow milk", HFR_Native.GetOption(0) != 0, compatFlags)
    Else
        AddHeaderOption("Regrowth time (in-game days)")
        minOption = AddSliderOption("Minimum days", HFR_Native.GetMinimum(), "{0}")
        maxOption = AddSliderOption("Maximum days", HFR_Native.GetMaximum(), "{0}")
        inspectOption = AddTextOption("Inspect targeted plant", "Write to log")
    EndIf
EndEvent
Int Function FeatureIndex(Int option)
    If !featureOptions
        Return -1
    EndIf
    Int i = 0
    While i < 7
        If featureOptions[i] >= 0 && featureOptions[i] == option
            Return i
        EndIf
        i += 1
    EndWhile
    Return -1
EndFunction
Event OnOptionSliderOpen(Int option)
    Int index = FeatureIndex(option)
    If option == minOption && minOption >= 0
        SetSliderDialogStartValue(HFR_Native.GetMinimum())
        SetSliderDialogDefaultValue(3)
        SetSliderDialogRange(1, 30)
    ElseIf option == maxOption && maxOption >= 0
        SetSliderDialogStartValue(HFR_Native.GetMaximum())
        SetSliderDialogDefaultValue(5)
        SetSliderDialogRange(HFR_Native.GetMinimum(), 30)
    ElseIf index == 3 || index == 6
        SetSliderDialogStartValue(HFR_Native.GetOption(index))
        SetSliderDialogDefaultValue(4)
        SetSliderDialogRange(1, 30)
    Else
        Return
    EndIf
    SetSliderDialogInterval(1)
EndEvent
Event OnOptionSliderAccept(Int option, Float value)
    Int index = FeatureIndex(option)
    If option == minOption && minOption >= 0
        HFR_Native.SetMinimum(value as Int)
    ElseIf option == maxOption && maxOption >= 0
        HFR_Native.SetMaximum(value as Int)
    ElseIf index == 3 || index == 6
        HFR_Native.SetOption(index, value as Int)
    EndIf
    ForcePageReset()
EndEvent
Event OnOptionDefault(Int option)
    Int index = FeatureIndex(option)
    If option == minOption && minOption >= 0
        HFR_Native.SetMinimum(3)
    ElseIf option == maxOption && maxOption >= 0
        HFR_Native.SetMaximum(5)
    ElseIf index == 3 || index == 6
        HFR_Native.SetOption(index, 4)
    ElseIf index == 2 || index == 4 || index == 5
        HFR_Native.SetOption(index, 0)
    ElseIf index >= 0
        HFR_Native.SetOption(index, 1)
    EndIf
    ForcePageReset()
EndEvent
Event OnOptionSelect(Int option)
    If option == inspectOption && inspectOption >= 0
        HFR_Native.Inspect()
        ShowMessage("Plant state written to HarvestableFloraRegrows.log. Aim at a plant before opening MCM.", false)
        Return
    EndIf
    Int index = FeatureIndex(option)
    If index >= 0 && index != 3 && index != 6
        If HFR_Native.GetOption(index) == 0
            HFR_Native.SetOption(index, 1)
        Else
            HFR_Native.SetOption(index, 0)
        EndIf
        ForcePageReset()
    EndIf
EndEvent
Event OnOptionHighlight(Int option)
    Int index = FeatureIndex(option)
    If index == 0
        SetInfoText("Optional milk restoration using the universal random cooldown. Cows already milked when first initialized are restored immediately. Animations and milk rewards stay controlled by Immersive Interactions.")
    ElseIf index == 1 || index == 4
        SetInfoText("Allow this Nirnroot type to regrow. While disabled, it stays picked. Its saved deadline is preserved and can become overdue.")
    ElseIf index == 2 || index == 5
        SetInfoText("On: use this type's custom day slider. Off: use universal minimum and maximum. Applies when a new timer is assigned.")
    ElseIf index == 3 || index == 6
        SetInfoText("Fixed regrowth time for this Nirnroot type, in game days. Used only with custom time enabled. Range 1-30, default 4.")
    Else
        SetInfoText("Each picked plant gets one random deadline within these bounds. Existing timers are preserved. Raising minimum also raises maximum if needed. Sleeping, waiting and travel advance time.")
    EndIf
EndEvent
