Scriptname HFR_Native Hidden Native
Int Function GetMinimum() Global Native
Int Function GetMaximum() Global Native
Function SetMinimum(Int days) Global Native
Function SetMaximum(Int days) Global Native

Function Completed(ObjectReference plant) Global Native

Function Inspect() Global Native

Int Function GetOption(Int index) Global Native
Function SetOption(Int index, Int value) Global Native
Bool Function MilkAvailable() Global Native
Function MilkCompleted(ObjectReference cow) Global Native
Bool Function CanRestoreMilk(ObjectReference cow) Global Native
Bool Function CanRegrow(ObjectReference plant) Global Native
Bool Function IsScriptedNirn(ObjectReference plant) Global Native
