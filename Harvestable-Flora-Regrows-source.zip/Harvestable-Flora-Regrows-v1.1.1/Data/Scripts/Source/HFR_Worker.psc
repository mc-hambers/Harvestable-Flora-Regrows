Scriptname HFR_Worker Hidden
Function Regrow(ObjectReference plant) Global
    If plant && HFR_Native.CanRegrow(plant)
        If HFR_Native.IsScriptedNirn(plant)
            NirnrootACTIVATORScript original = plant as NirnrootACTIVATORScript
            If original && original.GetState() == "AlreadyHarvested"
                If original.NirnrootEmptyReference
                    original.NirnrootEmptyReference.DisableNoWait()
                    original.NirnrootEmptyReference.Delete()
                EndIf
                String readyState = "WaitingForHarvest"
                original.GotoState(readyState)
                plant.Enable()
                original.OnCellAttach()
            EndIf
        Else
            plant.SetHarvested(false)
        EndIf
        HFR_Native.Completed(plant)
    EndIf
EndFunction
Function RestoreMilk(FormList used, ObjectReference cow) Global
    If used && cow && HFR_Native.CanRestoreMilk(cow)
        used.RemoveAddedForm(cow)
        HFR_Native.MilkCompleted(cow)
    EndIf
EndFunction
