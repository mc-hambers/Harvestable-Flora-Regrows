# Validation and in-game checks
Native compilation, 3889 deterministic timer boundary checks, Papyrus compilation, ESL flag/SEQ/metadata and ZIP integrity are checked locally. Full game and SKSE co-save integration tests are not run.

1. Enable the ESP and load using SKSE. Confirm MCM Minimum 3 / Maximum 5.
2. Set Minimum above Maximum: Maximum rises to match. Max slider cannot go below Min. Both endpoints clamp 1�30.
3. Pick a standard crop/flower and wait beyond five in-game days; its harvested appearance and activation should return. Re-pick and verify a fresh deadline rather than immediate repeat regrowth.
4. Load an already harvested area; plants start their own new deadlines. No attempt to reconstruct unknown harvest dates.
5. Save before a deadline, reload with its .skse co-save and verify elapsed time is retained. Test save A/save B separation and new-game clearing.
6. Leave the cell, wait past the deadline, return; loaded plants catch up. Confirm vanilla resets or other restoration clear obsolete timers.
7. Test mod-added FLOR/TREE produce, interiors and exteriors. Scripted activators/ore are excluded.
8. Test fast travel, sleeping/waiting and densely planted fields for bounded catch-up. Settings changes preserve already chosen deadlines.

Install archive allowlist: ESP, SEQ, three gameplay PEX files, DLL, INI and LICENSE. No API headers, tools, docs or source.

 v1.0.1 fixes tracking gaps found during code review; runtime root cause unconfirmed. Inspect a harvested plant, confirm assigned deadline and advancing game day in log, wait past deadline and inspect request/completion. Test initial load, persistent cells, newly entered cells, unloaded catch-up and save/reload.

## v1.1.0 checks still requiring Skyrim
- Without Immersive Interactions: no missing-master dependency, compatibility unavailable, normal flora unaffected.
- Existing used cow: restored immediately on first initialization; keg and non-cow entries unchanged.
- Milk again: original animation/two milk reward, then a single universal deadline; reload retains it and does not bootstrap again.
- Disable/re-enable compatibility: no restoration while off; pending deadline retained. Add integration to an older save and test unresolved old cows.
- Both Nirnroot types: harvest, walk away/return, verify disabled original tracked, custom versus universal deadlines, spent visual removed and vanilla glow/sound restored. Reharvest increases vanilla quest/stat count only through the original harvest interaction.
- Each regrowth checkbox and custom-time checkbox independently; sliders grey out correctly and stay within 1-30. Assigned deadlines preserved.
- Save before/after bootstrap and before/after regrowth; switch between saves. Use co-save with matching save.
Archive and source inspection confirm target list/race IDs and vanilla Nirnroot script states. Runtime integration is not yet verified.

 v1.1.1: verify native fallback and shipped INI disable Crimson regrowth; MCM reset of Crimson checkbox disables it. Existing saved preference is retained; regular Nirnroot remains enabled.
