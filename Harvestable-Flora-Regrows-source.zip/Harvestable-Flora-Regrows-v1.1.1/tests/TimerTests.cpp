#include "../src/TimerRules.h"
#include "../src/FeatureRules.h"
#include <cassert>
#include <iostream>
int main(){int checks=0;for(int lo=-2;lo<=33;lo++)for(int hi=-2;hi<=33;hi++)for(double roll:{0.0,0.5,1.0}){double due=Deadline(42,lo,hi,roll);assert(due>=43 && due<=72);assert(due>=42+BoundDays(lo));checks++;}assert(Deadline(10,3,3,0.9)==13);assert(NirnKindForBase(0xE1FB2)==1);assert(NirnKindForBase(0xB6FB9)==2);assert(!IsNirnBase(0x59B86));
assert(FeatureDeadline(10,3,5,true,7,0.4)==17);
assert(FeatureDeadline(10,3,5,false,7,0.5)==14);
assert(MilkDue(true,1,100));assert(!MilkDue(false,1,100));assert(MilkDue(false,100,100));
checks+=8;std::cout<<"Passed "<<checks+1<<" deadline boundary checks\n";}
