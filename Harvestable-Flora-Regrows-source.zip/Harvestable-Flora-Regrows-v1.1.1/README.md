# Harvestable Flora Regrows v1.1.1
Harvestable flora regrows 3�5 in-game days after picking, without waiting for a cell reset. MCM Minimum and Maximum accept 1�30 days. Maximum cannot be below Minimum; raising Minimum raises Maximum when necessary. Changes affect new timers only.

SKSE handles loaded-reference tracking and save-specific deadlines. Already harvested plants get a random deadline when first observed loaded, because their original harvest time is unknown. Deadlines run in game-calendar time even while the plant is unloaded; overdue plants regrow when loaded again. Sleep/wait/fast travel advance timers. Only harvestable FLOR/TREE records with produce are supported; scripted activators, ore veins and containers need separate adapters. Other mods using those standard records are covered without record overrides. Cell resets and externally restored plants clear their pending timer once observed. A small Papyrus helper invokes SKSE SetHarvested to refresh the model; there are no per-plant scripts or Papyrus polling loops. Native checks process at most 256 loaded plants per two seconds and request at most 16 regrowth operations per pass.

Requirements: Skyrim SE/AE Steam, matching SKSE64 and Address Library, SkyUI for MCM, Visual C++ v14 x64 runtime. Install the gameplay ZIP and enable HarvestableFloraRegrows.esp (ESL/light). Keep the SKSE co-save with its matching save. Missing co-save timers are assigned afresh when plants load. Mod settings are shared across saves; plant deadlines are save-specific.

## Integrations
Vanilla flora/crops and mod-added harvestable FLOR/TREE records are handled through existing harvest flags. No dependency on Standing Pickpocket. Other regrowth mods may compete; do not combine their timers for the same plants.

## Build
Development Build-Native.ps1 currently uses the sibling Standing Pickpocket toolchain/dependency copy. Release workspace contains copied dependencies and a self-contained build configuration. Run Build-HarvestableFloraRegrows.bat; logs are written to logs and releases to output.

## Validation
Compilation and deterministic timer/serialization/package checks are separate from gameplay. Existing-save MCM registration, visual regrowth, SE/AE runtime compatibility, sleeping, unloading, reharvesting and save/load need actual game testing.

## Additions we wanted to implement
None beyond the requested regrowth/MCM behavior. Scripted non-flora harvest sources would need explicit compatibility work.

 v1.1.0 replaces the player Update virtual hook with a bounded main-thread task scheduler. A ten-second loaded-grid rescan recovers plants missed during initial model attachment; unloaded cells are never loaded. Tracking uses attached cell state instead of requiring a 3D model. MCM Inspect targeted plant writes flag/day/deadline data to the SKSE log. Timer assignment, regrowth completion and 30-second heartbeat messages make live failures diagnosable.

## v1.1.0 integrations and Nirnroot
Immersive Interactions 1.78 is detected through ImmersiveInteractions.esp's AR_Interact_AlreadyUsed form (local 0x80A). Its RaceCow property points to Skyrim's cow race 0x4E785. The optional Compatibility-page toggle defaults on when available and is disabled in MCM when the dependency is absent. Only cows of that race are touched; the shared list's other actors, kegs, firewood and other interactions remain intact. Milk restoration removes the script-added cow entry and leaves rewards/animation to the original mod. New milk cooldowns use the universal random minimum/maximum, never the Nirnroot timing. A one-time per-save snapshot marks already-used entries as legacy: only cow entries are restored without delay. Unresolved old references retry when resolvable without loading their cells. Metadata, pending legacy IDs and milk deadlines are saved in the SKSE co-save, preventing a free reset on every reload. Enabling compatibility for the first time starts this migration. Disabling it stops restoration but preserves timers.

Correction to early compatibility claims: vanilla Nirnroot is an ACTI record with NirnrootACTIVATORScript, not a standard FLOR/TREE harvest flag. This release explicitly supports normal (base 0xE1FB2) and crimson (0xB6FB9) activators. It reads AlreadyHarvested state, tracks the disabled picked original, removes its spent empty-reference visual, restores WaitingForHarvest state and enables the original and calls its vanilla OnCellAttach handler to recreate glow and the new empty visual without requiring a cell reload. No original game script is overwritten, and no ingredients or quest progress are granted by regrowth. Overhauls replacing Nirnroot's script require separate validation.

The Nirnroot MCM page has Regrow Nirnroot and Regrow Crimson Nirnroot toggles (normal default on, crimson default off), plus separate Use custom time toggles (default off). Each custom day slider is 1-30 days, default 4. Custom time off uses universal minimum/maximum. New settings apply to newly assigned timers; assigned deadlines are preserved. Switching regrowth off prevents restoration until re-enabled, when overdue timers may complete.
