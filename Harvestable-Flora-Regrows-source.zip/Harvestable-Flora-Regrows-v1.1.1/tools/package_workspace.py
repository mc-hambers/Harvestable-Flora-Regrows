from pathlib import Path
import zipfile
r=Path(__file__).resolve().parents[1];out=r/'output/Harvestable-Flora-Regrows-v1.1.1-Workspace.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in r.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(r)
  if '.git' in rel.parts or rel.parts[0] in {'build','output'}:continue
  if rel.parts[:2]==('tools','msvc'):continue
  if rel.parts[0]=='Data' and p.suffix in {'.exp','.lib'}:continue
  z.write(p,'Harvestable-Flora-Regrows-v1.1.1/'+rel.as_posix())
 z.write(r/'output/Harvestable-Flora-Regrows-v1.1.1-SE-AE.zip','Harvestable-Flora-Regrows-v1.1.1/output/Harvestable-Flora-Regrows-v1.1.1-SE-AE.zip')
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('Workspace ZIP verified',out.stat().st_size,'bytes')
