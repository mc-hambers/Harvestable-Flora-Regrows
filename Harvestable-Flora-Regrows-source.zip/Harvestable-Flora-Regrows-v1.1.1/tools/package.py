from pathlib import Path
import zipfile,struct,ctypes
r=Path(__file__).resolve().parents[1];data=r/'Data'
b=(data/'HarvestableFloraRegrows.esp').read_bytes();assert struct.unpack_from('<I',b,8)[0]&0x200
assert (data/'Seq/HarvestableFloraRegrows.seq').read_bytes()==struct.pack('<I',0x01000800)
l=ctypes.WinDLL(str(data/'SKSE/Plugins/HarvestableFloraRegrows.dll'))
meta=bytes((ctypes.c_ubyte*0x350).in_dll(l,'SKSEPlugin_Version'));assert struct.unpack_from('<I',meta,4)[0]==0x01010010
assert struct.unpack_from('<I',meta,0x304)[0]&1
assert struct.unpack_from('<I',meta,0x308)[0]&1
out=r/'output/Harvestable-Flora-Regrows-v1.1.1-SE-AE.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in data.rglob('*'):
  if p.is_file() and p.suffix in {'.esp','.seq','.pex','.dll','.ini'}:z.write(p,p.relative_to(data).as_posix())
 z.write(r/'LICENSE','LICENSE')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert z.read('SKSE/Plugins/HarvestableFloraRegrows.dll')==(data/'SKSE/Plugins/HarvestableFloraRegrows.dll').read_bytes()
 assert set(z.namelist())=={
  'HarvestableFloraRegrows.esp','Seq/HarvestableFloraRegrows.seq',
  'Scripts/HFR_MCM.pex','Scripts/HFR_Native.pex','Scripts/HFR_Worker.pex',
  'SKSE/Plugins/HarvestableFloraRegrows.dll','SKSE/Plugins/HarvestableFloraRegrows.ini','LICENSE'}
 assert b'RestoreMilk' in z.read('Scripts/HFR_Worker.pex')
 assert b'nirnrootactivatorscript' in z.read('Scripts/HFR_Worker.pex').lower()
 assert b'Crimson Nirnroot' in z.read('Scripts/HFR_MCM.pex')
print('Verified light ESP, SEQ, native metadata, install contents and ZIP:',out)

