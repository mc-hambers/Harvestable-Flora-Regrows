Scriptname FormList extends Form Hidden
Function RemoveAddedForm(Form target) Native
