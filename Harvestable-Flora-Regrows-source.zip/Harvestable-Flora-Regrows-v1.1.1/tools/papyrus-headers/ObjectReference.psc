Scriptname ObjectReference extends Form Hidden
Bool Function IsHarvested() Native
Function SetHarvested(Bool harvested) Native

Function DisableNoWait(Bool fadeOut = false) Native
Function Delete() Native
Function Enable(Bool fadeIn = false) Native
