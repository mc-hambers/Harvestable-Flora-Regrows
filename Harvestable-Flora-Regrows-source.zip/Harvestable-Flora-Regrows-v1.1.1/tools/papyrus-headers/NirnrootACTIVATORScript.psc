; Compile-only declaration of vanilla script, never installed.
Scriptname NirnrootACTIVATORScript extends ObjectReference
ObjectReference Property NirnrootEmptyReference Auto

State WaitingForHarvest
EndState
State AlreadyHarvested
EndState
Event OnCellAttach()
EndEvent
