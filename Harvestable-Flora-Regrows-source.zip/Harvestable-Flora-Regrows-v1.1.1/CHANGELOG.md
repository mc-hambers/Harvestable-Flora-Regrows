# v1.1.1
- Default Crimson Nirnroot regrowth to off, including MCM reset-to-default.
- Regular Nirnroot remains on; existing saved preferences are preserved.

# v1.1.0
- Optional Immersive Interactions 1.78 cow-milking adapter, automatically detected without a hard dependency.
- Uses universal random cooldown, preserves its animations/rewards and clears only cow entries from the shared used list.
- One-time per-save restoration for already-milked cows; bootstrap state and pending milk timers survive saves.
- Explicit scripted vanilla Nirnroot and Crimson Nirnroot support, including disabled picked references, spent plant/glow cleanup and vanilla script state restoration.
- Separate regrowth toggles and custom 1-30-day sliders per Nirnroot type; disabled custom timing uses the universal range.
- Organized MCM pages: General, Nirnroot, Compatibility.

# v1.0.1
- Retry loaded-grid discovery and track attached-cell plants without requiring a finished model.
- Replace player Update hook with bounded native task scheduling.
- Add live plant inspection and timer/dispatch/heartbeat diagnostics.

# v1.0.0
- Random 3�5-day flora regrowth, MCM 1�30-day bounds, loaded picked-plant discovery and SKSE co-save persistence.
- Light ESP and minimal gameplay-only install archive.
