Harvestable Flora Regrows 1.1.2

OPTIMIZED: Object-load notifications are coalesced and processed in batches instead of submitting one game-thread task per object. Plant discovery/recovery scans inspect one attached cell per update; fallback discovery is scheduled every 60 seconds rather than rescanning all loaded references every 10 seconds. Initial discovery also uses the cell queue. Large/dense individual cells may still take more work than ordinary cells.

Plant processing changes from up to 256 checks and 16 requests every two seconds to up to 32 checks and two accepted requests every 250ms, retaining the same nominal maximum throughput while distributing it over smaller batches. Duplicate pending regrowth requests are suppressed for ten seconds or until completion; rejected requests release their slot. Gameplay pauses skip work. Late tasks from older save sessions are discarded. Milk processing retains its two-second interval. Routine per-plant diagnostic messages are debug-level; heartbeat and warning logs remain.

SAVE COMPATIBILITY: Existing regrowth/milk deadlines, random timing rules, plugin name, FormIDs, compiled scripts and save record formats are unchanged. All new queues and pending-request bookkeeping are runtime-only. Discovery is gradual after loading; missed object-load notifications are repaired by the incremental fallback scan.

INSTALL: Close Skyrim. Update the existing Harvestable Flora Regrows mod in Vortex and deploy. Retain your existing HarvestableFloraRegrows.ini when resolving configuration changes. No new save, save cleaner or Nemesis generation is required. Do not load a second copy of its DLL.

VALIDATION: Native build, loader/version checks and 3897 timer boundary checks passed. ESP and Papyrus files are unchanged. Actual regrowth behavior, dense-cell performance and frame-time improvements still require gameplay testing.
